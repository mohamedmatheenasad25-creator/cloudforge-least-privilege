# Least-Privilege Access Demo (CloudForge One Day Hackathon)

Restrict administrative access to a cloud test resource with least-privilege identities,
then prove on the real AWS service that unauthorized actions are denied.

## What it shows

| Requirement | How it is met |
|---|---|
| Separate admin and restricted identities | Admin: `AccountFullAccessRole` (temporary session). Restricted: `LeastPrivTesterRole`. |
| Only the permissions a defined task needs | The task is "read one bucket". Policy: `s3:ListBucket` on the bucket and `s3:GetObject` on its objects, nothing else. |
| One permitted and one denied admin action, on the real service | Permitted: list the bucket, read `hello.txt`. Denied: upload, delete a file, delete the bucket, create an IAM user. AWS returns `AccessDenied` for each. |
| No long-lived access keys | Everything uses roles and STS `AssumeRole`. The restricted credentials expire after 15 minutes. No access key is created anywhere. |
| Remove test identities afterwards | `cleanup_all.sh` deletes the roles, the Lambda, the bucket and the unused test user. |

## Architecture

```
Browser dashboard --HTTPS--> Lambda Function URL --> Lambda (LeastPrivBackendRole)
                                                        | sts:AssumeRole (15 min credentials)
                                                        v
                                              LeastPrivTesterRole (read one bucket)
                                                        |
                                                        v
                                            S3 bucket lp-demo-<account-id>
```

The backend role is itself restricted: it may only assume the tester role, read that role's
policy (to display it) and write its own logs.

## Run it (AWS CloudShell, region ap-southeast-2)

1. In CloudShell choose Actions, Upload file, and pick `cloudforge.zip`.
2. `python3 -m zipfile -e cloudforge.zip cloudforge && cd cloudforge`
3. `bash deploy.sh` (about 2 minutes). It prints the dashboard URL and a self-test result.
4. Open the URL and press "Run all tests".

Terminal alternative: `python3 lambda_function.py` (needs `TESTER_ROLE_ARN` and `BUCKET`, which `deploy.sh` sets on the Lambda).

## Evidence for judges

* Dashboard: "Download evidence (JSON)" button.
* `selftest-evidence.json` written by `deploy.sh`.
* `bash evidence.sh` shows the CloudTrail audit trail (AssumeRole, and the refused CreateUser / DeleteBucket calls). Events appear 5 to 15 minutes after a run.

## Clean up

`bash cleanup_all.sh` (type `DELETE` to confirm). It verifies at the end that everything is gone.

## Files

* `lambda_function.py` backend, `index.html` dashboard
* `deploy.sh`, `cleanup_all.sh`, `evidence.sh`
